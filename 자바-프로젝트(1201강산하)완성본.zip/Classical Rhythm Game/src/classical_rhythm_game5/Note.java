package classical_rhythm_game5;

import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Note extends Thread {

	private Image noteBasicImage = new ImageIcon(Main.class.getResource("../images/noteBasic.png")).getImage();
	private int x, y = 580 - 1000 / Main.SLEEP_TIME * Main.NOTE_SPEED;
	private String noteType;
	private boolean procceded = true;

	public String getNoteType() {
		return noteType;
	}

	public boolean isProcced() {
		return procceded;
	}

	public void close() {// ��Ʈ�� �츮�� ����� �Է��ߴ�.
		procceded = false;
	}

	public Note(String noteType) {
		if (ClassicalRhythmGame.game.getUser().equals("single")) {
			if (noteType.equals("S")) {
				x = 228;
			} else if (noteType.equals("D")) {
				x = 332;
			} else if (noteType.equals("F")) {
				x = 436;
			} else if (noteType.equals("Space")) {
				x = 540;
			} else if (noteType.equals("J")) {
				x = 744;
			} else if (noteType.equals("K")) {
				x = 848;
			} else if (noteType.equals("L")) {
				x = 952;
			}
			this.noteType = noteType;
		} else {
			if (noteType.equals("A")) {
				x = 228;
			} else if (noteType.equals("S")) {
				x = 332;
			} else if (noteType.equals("D")) {
				x = 436;
			} else if (noteType.equals("J")) {
				x = 744;
			} else if (noteType.equals("K")) {
				x = 848;
			} else if (noteType.equals("L")) {
				x = 952;
			}
			this.noteType = noteType;
		}

	}

	public void screenDraw(Graphics2D g) {
		if (ClassicalRhythmGame.game.getUser().equals("single"))
			if (!noteType.equals("Space")) {
				g.drawImage(noteBasicImage, x, y, null);
			} else {
				g.drawImage(noteBasicImage, x, y, null);
				g.drawImage(noteBasicImage, x + 100, y, null);// �ٸ� ��Ʈ�� ���ؼ� �� ��Ʈ
			}
		else {

			g.drawImage(noteBasicImage, x, y, null);

		}
	}

	public void drop() {
		y += Main.NOTE_SPEED;// �Ʒ������� ���� ������ �ӵ���ŭ������
		if (y > 620) {

			close();

		}
	}

	@Override
	public void run() {
		try {
			while (true) {
				drop();
				if (procceded) {
					Thread.sleep(Main.SLEEP_TIME); // ���� �ð� �ٿ��ֱ�.
				} else {
					interrupt();
					break;
				}

			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public String judge() {

		if (y >= 590) {

			close();
			return "Good";

		} else if (y >= 500) {

			close();
			return "Perfect";

		} else if (y >= 450) {

			close();
			return "Early";

		}
		return "None";

	}

	public int getY() {
		return y;
	}

}
