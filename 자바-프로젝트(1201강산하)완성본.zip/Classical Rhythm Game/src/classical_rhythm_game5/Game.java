package classical_rhythm_game5;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;

public class Game extends Thread {

	private Image noteRouteLineImage = new ImageIcon(Main.class.getResource("../images/noteRouteLine.png")).getImage();
	private Image judgementLineImage = new ImageIcon(Main.class.getResource("../images/judgementLine.png")).getImage();
	private Image gameInfoImage = new ImageIcon(Main.class.getResource("../images/gameInfo.png")).getImage();

	private Image noteRouteSImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteDImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteFImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteSpace1Image = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteSpace2Image = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteJImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteKImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	private Image noteRouteLImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();

	private Image judgeImage;

	private String titleName;
	private String user;
	private String musicTitle;
	private Music gameMusic;
	private boolean gameMaker = false;

	private int score = 0;

	ArrayList<Note> noteList = new ArrayList<>();

	public Game(String titleName, String user, String musicTitle) {

		this.titleName = titleName;
		this.user = user;
		this.musicTitle = musicTitle;
		gameMusic = new Music(this.musicTitle, false);

	}

	public String getUser() {
		return user;
	}

	public void screenDraw(Graphics2D g) {
		if (user.equals("multi")) {
			g.drawImage(noteRouteSImage, 228, 30, null);
			g.drawImage(noteRouteDImage, 332, 30, null);
			g.drawImage(noteRouteFImage, 436, 30, null);
			// g.drawImage(noteRouteSpace1Image, 540, 30, null);
			// g.drawImage(noteRouteSpace2Image, 640, 30, null);
			g.drawImage(noteRouteJImage, 744, 30, null);
			g.drawImage(noteRouteKImage, 848, 30, null);
			g.drawImage(noteRouteLImage, 952, 30, null);
			g.drawImage(noteRouteLineImage, 224, 30, null);
			g.drawImage(noteRouteLineImage, 328, 30, null);
			g.drawImage(noteRouteLineImage, 432, 30, null);
			g.drawImage(noteRouteLineImage, 536, 30, null);
			g.drawImage(noteRouteLineImage, 740, 30, null);
			g.drawImage(noteRouteLineImage, 844, 30, null);
			g.drawImage(noteRouteLineImage, 948, 30, null);
			g.drawImage(noteRouteLineImage, 1052, 30, null);
			g.drawImage(gameInfoImage, 0, 660, null);
			g.drawImage(judgementLineImage, 0, 580, null);
			g.drawImage(judgeImage, 460, 420, null);
			scoreDraw(g);
			for (int i = 0; i < noteList.size(); i++) {

				Note note = noteList.get(i);
				if (note.getY() > 620) {
					
					score-=1500;
					g.setFont(new Font("Elephant", Font.BOLD, 30));
					g.drawString("Score: " + score, 565, 702);
					judgeImage = new ImageIcon(Main.class.getResource("../images/miss.png")).getImage();
					
				} 

				if (!note.isProcced()) {
					noteList.remove(i);
					i--;
				} else {
					note.screenDraw(g);
				}

			}
			g.setColor(Color.black);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setFont(new Font("Arial", Font.BOLD, 30));
			g.drawString(titleName, 20, 702);
			g.drawString(user, 1190, 702);
			g.setFont(new Font("Arial", Font.PLAIN, 26));
			g.setColor(Color.WHITE);
			g.drawString("A", 270, 609);
			g.drawString("S", 374, 609);
			g.drawString("D", 478, 609);
			// g.drawString("Space Bar", 580, 609);
			g.drawString("J", 784, 609);
			g.drawString("K", 889, 609);
			g.drawString("L", 993, 609);
			g.setColor(Color.DARK_GRAY);
		} else {
			g.drawImage(noteRouteSImage, 228, 30, null);
			g.drawImage(noteRouteDImage, 332, 30, null);
			g.drawImage(noteRouteFImage, 436, 30, null);
			g.drawImage(noteRouteSpace1Image, 540, 30, null);
			g.drawImage(noteRouteSpace2Image, 640, 30, null);
			g.drawImage(noteRouteJImage, 744, 30, null);
			g.drawImage(noteRouteKImage, 848, 30, null);
			g.drawImage(noteRouteLImage, 952, 30, null);
			g.drawImage(noteRouteLineImage, 224, 30, null);
			g.drawImage(noteRouteLineImage, 328, 30, null);
			g.drawImage(noteRouteLineImage, 432, 30, null);
			g.drawImage(noteRouteLineImage, 536, 30, null);
			g.drawImage(noteRouteLineImage, 740, 30, null);
			g.drawImage(noteRouteLineImage, 844, 30, null);
			g.drawImage(noteRouteLineImage, 948, 30, null);
			g.drawImage(noteRouteLineImage, 1052, 30, null);
			g.drawImage(gameInfoImage, 0, 660, null);
			g.drawImage(judgementLineImage, 0, 580, null);
			g.drawImage(judgeImage, 460, 420, null);
			scoreDraw(g);
			for (int i = 0; i < noteList.size(); i++) {

				Note note = noteList.get(i);
				if (note.getY() > 620) {
					score -= 1500;
					g.setFont(new Font("Elephant", Font.BOLD, 30));
					g.drawString("Score: " + score, 565, 702);
					judgeImage = new ImageIcon(Main.class.getResource("../images/miss.png")).getImage();
				}

				if (!note.isProcced()) {
					noteList.remove(i);
					i--;
				} else {
					note.screenDraw(g);
				}

			}
			g.setColor(Color.black);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setFont(new Font("Arial", Font.BOLD, 30));
			g.drawString(titleName, 20, 702);
			g.drawString(user, 1190, 702);
			g.setFont(new Font("Arial", Font.PLAIN, 26));
			g.setColor(Color.WHITE);
			g.drawString("S", 270, 609);
			g.drawString("D", 374, 609);
			g.drawString("F", 478, 609);
			g.drawString("Space Bar", 580, 609);
			g.drawString("J", 784, 609);
			g.drawString("K", 889, 609);
			g.drawString("L", 993, 609);
			g.setColor(Color.DARK_GRAY);
			// g.setFont(new Font("Elephant", Font.BOLD, 30));
			// g.drawString(""+score, 565, 702);
		}

	}

	private void scoreDraw(Graphics2D g) {
		for (int i = 0; i < noteList.size(); i++) {
			g.setFont(new Font("Elephant", Font.BOLD, 30));
			g.drawString("Score: " + score, 565, 702);
		}

	}

	public void pressA() {
		if (user.equals("multi")) {
			judge("A");
			noteRouteSImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
			if (gameMaker == true) {
				System.out.println(gameMusic.getTime() + " A");
			}
		}

	}

	public void releaseA() {
		if (user.equals("multi")) {
			noteRouteSImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		}
	}

	public void pressS() {
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " S");
		}
		if (user.equals("multi")) {
			noteRouteDImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
			judge("S");
		} else {
			judge("S");
			noteRouteSImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		}

	}

	public void releaseS() {
		if (user.equals("multi")) {
			noteRouteDImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		} else {
			noteRouteSImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		}

	}

	public void pressD() {
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " D");
		}
		if (user.equals("multi")) {
			noteRouteFImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
			judge("D");
		} else {
			judge("D");
			noteRouteDImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		}

	}

	public void releaseD() {
		if (user.equals("multi")) {
			noteRouteFImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		} else {
			noteRouteDImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		}

	}

	public void pressF() {
		judge("F");
		noteRouteFImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " F");
		}

	}

	public void releaseF() {
		noteRouteFImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	}

	public void pressSpace() {
		judge("Space");
		noteRouteSpace1Image = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		noteRouteSpace2Image = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " Space");
		}

	}

	public void releaseSpace() {
		noteRouteSpace1Image = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
		noteRouteSpace2Image = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	}

	public void pressJ() {
		judge("J");
		noteRouteJImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " J");
		}

	}

	public void releaseJ() {
		noteRouteJImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	}

	public void pressK() {
		judge("K");
		noteRouteKImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " K");
		}

	}

	public void releaseK() {
		noteRouteKImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	}

	public void pressL() {
		judge("L");
		noteRouteLImage = new ImageIcon(Main.class.getResource("../images/noteRoutePressed.png")).getImage();
		if (gameMaker == true) {
			System.out.println(gameMusic.getTime() + " L");
		}

	}

	public void releaseL() {
		noteRouteLImage = new ImageIcon(Main.class.getResource("../images/noteRoute.png")).getImage();
	}

	@Override
	public void run() {
		dropNotes();

	}

	public void close() {
		gameMusic.close();
		this.interrupt();
	}

	public void dropNotes() {
		if (musicTitle.equals("Carmen by Bizet.mp3") && user.equals("single")) {
			try {

				File file = new File("D:\\java_workspace\\Classical Rhythm Game\\src\\TEXT\\Carmen_by_Bizet.txt");

				FileReader filereader = new FileReader(file);
				BufferedReader in = new BufferedReader(filereader);

				int cnt = 1076;

				Beat[] beats = new Beat[cnt];

				int j = 0;
				String s;
				while ((s = in.readLine()) != null) {
					String[] ch = s.split(" ");
					beats[j] = new Beat(Integer.parseInt(ch[0]) - 990, ch[1]);
					j++;
				}
				int i = 0;
				gameMusic.start();
				while (true) {
					if (beats[i].getTime() <= gameMusic.getTime()) {
						Note note = new Note(beats[i].getNoteName());
						note.start();
						noteList.add(note);
						i++;
					}
				}
			} catch (FileNotFoundException e) {
				// TODO: handle exception
			} catch (IOException e) {
				System.out.println(e);
			}
		} else if (musicTitle.equals("Carmen by Bizet.mp3") && user.equals("multi")) {
			try {

				// ���� ��ü ����
				File file = new File("D:\\java_workspace\\Classical Rhythm Game\\src\\TEXT\\Carmen_by_Bizet_multi.txt");
				// �Է� ��Ʈ�� ����
				FileReader filereader = new FileReader(file);
				BufferedReader in = new BufferedReader(filereader);
				// String x;
				int cnt = 3865;
//				while ((x = in.readLine()) != null) {
//					cnt++;
//				}
//					 System.out.println(cnt);

				Beat[] beats = new Beat[cnt];
				// System.out.println(beats.length);
				int j = 0;
				String s;
//				int bpm;
//				String key;

				while ((s = in.readLine()) != null) {
					// System.out.println(s);
					String[] ch = s.split(" ");
//					bpm = Integer.parseInt(ch[0]);
//					key = ch[1];

					beats[j] = new Beat(Integer.parseInt(ch[0]) - 990, ch[1]);
//					System.out.println("111");
					j++;
				}
//				System.out.println(beats[1].getTime());
//				System.out.println(beats[0].getNoteName());
				int i = 0;
				gameMusic.start();
				// beats[0]=new Beat(1,"Space");
				while (true) {
					if (beats[i].getTime() <= gameMusic.getTime()) {
						Note note = new Note(beats[i].getNoteName());
						note.start();
						noteList.add(note);
						i++;
					}
				}
			} catch (FileNotFoundException e) {
				// TODO: handle exception
			} catch (IOException e) {
				System.out.println(e);
			}

		} else if (musicTitle.equals("C Major Prelude by Bach.mp3") && user.equals("single")) {
			try {

				// ���� ��ü ����
				File file = new File("D:\\java_workspace\\Classical Rhythm Game\\src\\TEXT\\C_Major.txt");
				// �Է� ��Ʈ�� ����
				FileReader filereader = new FileReader(file);
				BufferedReader in = new BufferedReader(filereader);
				// String x;
				int cnt = 260;
//			while ((x = in.readLine()) != null) {
//				cnt++;
//			}
				// System.out.println(cnt);

				Beat[] beats = new Beat[cnt];
				// System.out.println(beats.length);
				int j = 0;
				String s;
//			int bpm;
//			String key;

				while ((s = in.readLine()) != null) {
					// System.out.println(s);
					String[] ch = s.split(" ");
//				bpm = Integer.parseInt(ch[0]);
//				key = ch[1];

					beats[j] = new Beat(Integer.parseInt(ch[0]) - 990 + 480, ch[1]);
//				System.out.println("111");
					j++;
				}
//			System.out.println(beats[1].getTime());
//			System.out.println(beats[0].getNoteName());
				int i = 0;
				gameMusic.start();
				// beats[0]=new Beat(1,"Space");
				while (true) {
					if (beats[i].getTime() <= gameMusic.getTime()) {
						Note note = new Note(beats[i].getNoteName());
						note.start();
						noteList.add(note);
						i++;
					}
				}
			} catch (FileNotFoundException e) {
				// TODO: handle exception
			} catch (IOException e) {
				System.out.println(e);
			}

		} else if (musicTitle.equals("Hungarian Dance - Brahms.mp3") && user.equals("single")) {
			try {

				// ���� ��ü ����
				File file = new File("D:\\java_workspace\\Classical Rhythm Game\\src\\TEXT\\HungarianDance.txt");
				// �Է� ��Ʈ�� ����
				FileReader filereader = new FileReader(file);
				BufferedReader in = new BufferedReader(filereader);
				// String x;
				int cnt = 684;
//			while ((x = in.readLine()) != null) {
//				cnt++;
//			}
				// System.out.println(cnt);

				Beat[] beats = new Beat[cnt];
				// System.out.println(beats.length);
				int j = 0;
				String s;
//			int bpm;
//			String key;

				while ((s = in.readLine()) != null) {
					// System.out.println(s);
					String[] ch = s.split(" ");
//				bpm = Integer.parseInt(ch[0]);
//				key = ch[1];

					beats[j] = new Beat(Integer.parseInt(ch[0]) - 990 + 320, ch[1]);
//				System.out.println("111");
					j++;
				}
//			System.out.println(beats[1].getTime());
//			System.out.println(beats[0].getNoteName());
				int i = 0;
				gameMusic.start();
				// beats[0]=new Beat(1,"Space");
				while (true) {
					if (beats[i].getTime() <= gameMusic.getTime()) {

						Note note = new Note(beats[i].getNoteName());
						note.start();
						noteList.add(note);
						i++;
					}
				}
			} catch (FileNotFoundException e) {
				// TODO: handle exception
			} catch (IOException e) {
				System.out.println(e);
			}
		}

	}

	public void judge(String input) {
		for (int i = 0; i < noteList.size(); i++) {

			Note note = noteList.get(i);
			if (input.equals(note.getNoteType())) {
				judgeEvent(note.judge());

				break;
			}
		}
	}

	public void judgeEvent(String judge) {
		
			if (judge.equals("Miss")) {
				// score+=10000;
				judgeImage = new ImageIcon(Main.class.getResource("../images/miss.png")).getImage();

			} else if (judge.equals("Good")) {
				judgeImage = new ImageIcon(Main.class.getResource("../images/good.png")).getImage();
				score += 500;
			} else if (judge.equals("Perfect")) {
				judgeImage = new ImageIcon(Main.class.getResource("../images/Perfect.png")).getImage();
				score += 1000;
			} else if (judge.equals("Early")) {
				judgeImage = new ImageIcon(Main.class.getResource("../images/Early.png")).getImage();
				score += 100;
			
		}
	}

}
