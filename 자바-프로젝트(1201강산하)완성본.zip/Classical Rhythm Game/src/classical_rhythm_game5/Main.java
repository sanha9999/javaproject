package classical_rhythm_game5;

public class Main {//���ο��� ����
	
	public static final int SCREEN_WIDTH =1280; 
	public static final int SCREEN_HEIGHT=720;
	public static final int NOTE_SPEED = 8;
	public static final int SLEEP_TIME = 10;
	public static final int REACH_TIME = 1; 
	 
 
	public static void main(String[] args) {
		
		new ClassicalRhythmGame();

	} 

}
