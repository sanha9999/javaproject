package classical_rhythm_game5.copy;

public class Main {//���ο��� ����
	
	public static final int SCREEN_WIDTH =1280; 
	public static final int SCREEN_HEIGHT=720;
	public static final int NOTE_SPEED = 7;
	public static final int SLEEP_TIME = 10;
	
 
	public static void main(String[] args) {
		
		new ClassicalRhythmGame();

	} 

}
